/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.5.5-10.1.26-MariaDB : Database - e_services
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`e_services` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `e_services`;

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `ad_id` int(11) NOT NULL AUTO_INCREMENT,
  `ad_name` varchar(50) DEFAULT NULL,
  `ad_pass` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ad_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `admin` */

LOCK TABLES `admin` WRITE;

insert  into `admin`(`ad_id`,`ad_name`,`ad_pass`) values (1,'rahul','rahul');

UNLOCK TABLES;

/*Table structure for table `bookservice` */

DROP TABLE IF EXISTS `bookservice`;

CREATE TABLE `bookservice` (
  `book_id` int(11) NOT NULL,
  `date` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `customer_cu_id` int(11) DEFAULT NULL,
  `service_ser_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`book_id`),
  KEY `FK56cvsrp0n675un6ec13pjk6me` (`customer_cu_id`),
  KEY `FKhvjc6popo42oayl9rynilc7kq` (`service_ser_id`),
  CONSTRAINT `FK56cvsrp0n675un6ec13pjk6me` FOREIGN KEY (`customer_cu_id`) REFERENCES `customer` (`cu_id`),
  CONSTRAINT `FKhvjc6popo42oayl9rynilc7kq` FOREIGN KEY (`service_ser_id`) REFERENCES `service` (`ser_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `bookservice` */

LOCK TABLES `bookservice` WRITE;

insert  into `bookservice`(`book_id`,`date`,`status`,`customer_cu_id`,`service_ser_id`) values (18,'2018-02-09','Completed',17,6),(21,'2018-02-10','booked',17,6),(22,'2018-02-09','Confirm',17,4);

UNLOCK TABLES;

/*Table structure for table `customer` */

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `cu_id` int(11) NOT NULL,
  `cu_add` varchar(255) DEFAULT NULL,
  `cu_city` varchar(255) DEFAULT NULL,
  `cu_email` varchar(255) DEFAULT NULL,
  `cu_gender` varchar(255) DEFAULT NULL,
  `cu_name` varchar(255) DEFAULT NULL,
  `cu_num` bigint(20) DEFAULT NULL,
  `cu_pass` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `customer` */

LOCK TABLES `customer` WRITE;

insert  into `customer`(`cu_id`,`cu_add`,`cu_city`,`cu_email`,`cu_gender`,`cu_name`,`cu_num`,`cu_pass`) values (17,'vadtal','ahmedabad','rahul.patidar@tops-int.com','male','rahul',9712141008,'111');

UNLOCK TABLES;

/*Table structure for table `file` */

DROP TABLE IF EXISTS `file`;

CREATE TABLE `file` (
  `f_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`f_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `file` */

LOCK TABLES `file` WRITE;

insert  into `file`(`f_id`,`name`,`path`) values (1,'i2-l-003302.jpg','E:\\JAVA\\WorkSpace\\New WorkSpace\\E-services\\WebContent\\image\\i2-l-003302.jpg'),(2,'if-java-is-the-engine-then-spring-is-the-fuel.jpg','E:\\JAVA\\WorkSpace\\New WorkSpace\\E-services\\WebContent\\image\\if-java-is-the-engine-then-spring-is-the-fuel.jpg');

UNLOCK TABLES;

/*Table structure for table `hibernate_sequence` */

DROP TABLE IF EXISTS `hibernate_sequence`;

CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hibernate_sequence` */

LOCK TABLES `hibernate_sequence` WRITE;

insert  into `hibernate_sequence`(`next_val`) values (37);

UNLOCK TABLES;

/*Table structure for table `message` */

DROP TABLE IF EXISTS `message`;

CREATE TABLE `message` (
  `msg_id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mesage` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`msg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `message` */

LOCK TABLES `message` WRITE;

insert  into `message`(`msg_id`,`email`,`mesage`,`name`) values (19,'rahul.patidar@tops-int.com',' fdfdsfdsfds','rahul'),(20,'rahfdfdsf',' dsdsfsfsdf','rahul'),(22,'rahul.patidar@tops-int.com',' gfgfdgdgfdgfdgfdgfdg','rahul'),(23,'rahul.patidar@tops-int.com',' gfgfdgdfgdfgfdgfdgfgfdg','rahul');

UNLOCK TABLES;

/*Table structure for table `service` */

DROP TABLE IF EXISTS `service`;

CREATE TABLE `service` (
  `ser_id` int(11) NOT NULL,
  `ser_name` varchar(255) DEFAULT NULL,
  `ser_subname` varchar(255) DEFAULT NULL,
  `ser_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ser_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `service` */

LOCK TABLES `service` WRITE;

insert  into `service`(`ser_id`,`ser_name`,`ser_subname`,`ser_type`) values (3,'Bike Service','wheel changing','Automobile'),(4,'Car Spa','carspa','Automobile'),(5,'Interior Painting','wood painting','Painting'),(6,'Laptop','laptop repairing','Computer'),(7,'Wiring','wall wiring','Electrical'),(8,'Refrigerater','tv repair','Appliancis'),(24,'Refrigerater','trtr','Electrical'),(25,'Fan','fdfdsf','Electrical'),(26,'Bathroom fitting','kjhkhkhk','Plumbing'),(27,'Fan','vgfggffdg','Electrical'),(28,'Fan','gfdgfdgd','Electrical'),(29,'Fan','gfdgfdg','Electrical'),(30,'Fan','gfdgfdgdfg','Electrical'),(31,'Fan','vcxvcxvxcv','Electrical'),(32,'Fan','vxcvxcvcxv','Electrical'),(33,'Fan','vxcvxcvcxvxcv','Electrical'),(34,'Fan','vcvcxvcxvxcv','Electrical'),(35,'Fan','vxcvxvxvxcv','Electrical'),(36,'Fan','vxcvxcvxcv','Electrical');

UNLOCK TABLES;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
