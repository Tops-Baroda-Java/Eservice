package com.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.model.BookService;
import com.model.Service;
import com.util.dbutil;

public class Service_Dao {

	Session session;

	public void addService(Service service) {
		session=dbutil.getses();
		Transaction tr=session.beginTransaction();
		session.save(service);
		tr.commit();
		session.close();
	}
	public void updateService(Service service) {
		session=dbutil.getses();
		Transaction tr=session.beginTransaction();
		session.update(service);
		tr.commit();
		session.close();
	}
	public void deleteService(int ser_id) {
		session=dbutil.getses();
		Transaction tr=session.beginTransaction();
		Service service=session.get(Service.class, ser_id);
		session.delete(service);
		tr.commit();
		session.close();
	}
	public Service getService(int ser_id) {
		session=dbutil.getses();
		Service service=session.get(Service.class, ser_id);
		return service;
	}

	public List<Service> getallServices(String ser_type){
		session=dbutil.getses();
		List<Service> service=session.createQuery("from Service where ser_type='"+ser_type+"'").list();
		return service;
	}

	public void updateStatus(String status,int book_id) {
		session=dbutil.getses();
		Transaction tr=session.beginTransaction();
		Query query =	session.createQuery("from BookService b  where b.book_id=?");
		query.setParameter(0, book_id);
		BookService b=(BookService)query.uniqueResult();
		b.setStatus(status);
		session.saveOrUpdate(b);
		tr.commit();
		session.close();

	}



}
