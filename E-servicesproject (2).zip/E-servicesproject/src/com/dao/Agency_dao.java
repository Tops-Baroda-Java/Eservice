package com.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.model.Agency;
import com.model.Customer;
import com.util.dbutil;

public class Agency_dao {
	
	Session session;
	public void add_agency(Agency agency) {
		session=dbutil.getses();
		Transaction tr=session.beginTransaction();
		session.save(agency);
		tr.commit();
		session.close();
	}
	
	
	public boolean isagencyexist(Agency agency){
		session = dbutil.getses();
		boolean result = false;
		Transaction tx = null;
		try {
			tx=session.getTransaction();
			tx.begin();
			Query query= session.createQuery("from Agency where ag_email='"+agency.getAg_email()+"'");
			Agency agency2=(Agency)query.uniqueResult();
			tx.commit();
			if(agency2==null) result=true;
		} catch (Exception e) {
			if(tx!=null){
				tx.rollback();
			}
		}
		return result;
	}

	
	
	public List<Agency> getagency(){
		session=dbutil.getses();
		List<Agency> list=session.createQuery("from Agency").list();
		return list;
	}
	
	
	
}
