package com.dao;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.hibernate.Query;
import org.hibernate.Transaction;

import com.model.BookService;
import com.model.Customer;
import com.util.dbutil;

public class Customer_Datadao {


	org.hibernate.Session session;
	//------------------------------email-----------------------------------
	public void setemail(String cust_email,String sub, String mail_message) {


		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
		props.put("mail.smtp.ssl.trust", "smtp.gmail.com");

		Session session = Session.getInstance(props,
				new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("eservicesindia47@gmail.com","eservices@123");
			}
		});

		try {

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("fromSomeone@gmail.com"));
			message.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(cust_email));
			message.setSubject(sub);
			message.setText(mail_message);

			Transport.send(message);

		} catch (MessagingException e) {throw new RuntimeException(e);}  


	}






	//----------------------------------------------------------------registration services-------------------------------------------------
	public void insert(Customer customer){
		session=dbutil.getses();
		Transaction tr=session.beginTransaction();
		session.save(customer);
		tr.commit();
		session.close();
	}

	public boolean isuserexist(Customer customer){
		session = dbutil.getses();
		boolean result = false;
		Transaction tx = null;
		try {
			tx=session.getTransaction();
			tx.begin();
			Query query= session.createQuery("from Customer where cu_email='"+customer.getCu_email()+"'");
			Customer customer2=(Customer)query.uniqueResult();
			tx.commit();
			if(customer2==null) result=true;
		} catch (Exception e) {
			if(tx!=null){
				tx.rollback();
			}
		}
		finally {
			session.close();
		}
		return result;
	}
	//----------------------------------------login Service-----------------------------------------------------------------

	public boolean loginauthenticate(String email, String password){
		Customer customer=loginuser(email);
		if(customer!=null && customer.getCu_email().equals(email)&& customer.getCu_pass().equals(password)){
			return true;
		}
		else {
			return false;
		}
	}
	public Customer loginuser(String email){
		session = dbutil.getses();
		Transaction tx = null;
		Customer customer = null;
		try {
			customer=new Customer();
			tx=session.getTransaction();
			tx.begin();
			Query query=session.createQuery("from Customer where cu_email='"+email+"'");
			customer=(Customer)query.uniqueResult();
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}	
			e.printStackTrace();	 
		}
		return customer;
	}

	//-----------------------------------forgotpassword---------------------------------------------------
	public void updatepass(Customer customer) {
		session=dbutil.getses();
		Transaction tx = session.beginTransaction();
		session.update(customer);
		tx.commit();
		session.close();
	}


	//--------------------------------------book-services------------------------

	public void bookservice(BookService bookService) {
		session=dbutil.getses();
		Transaction tr=session.beginTransaction();
		session.save(bookService);
		tr.commit();
		session.close();
	}
			

	public BookService getBookingbyid(int book_id) {
		session=dbutil.getses();
		BookService bookService=session.get(BookService.class, book_id);
		return bookService;
	}




	//-----------------------------update customer---------------------------------

	public void updatecust(Customer customer) {
		session=dbutil.getses();
		Transaction tx= session.beginTransaction();
		session.update(customer);
		tx.commit();
		session.close();

	}
	
	//--------------------------------------send get an reply messaage-----------------------------------

	public void message(com.model.Message msg) {
		session=dbutil.getses();
		Transaction tx= session.beginTransaction();
		session.save(msg);
		tx.commit();
		session.close();
	}
	
	public List<com.model.Message> getallmessage(){
		session=dbutil.getses();
		List<com.model.Message> list=session.createQuery("from Message").list();
		return list;		
	}
	
	public com.model.Message getmesage(int id){
		session=dbutil.getses();
		com.model.Message message=session.get(com.model.Message.class, id);
		return message;
	}
	
	
	
	
}
