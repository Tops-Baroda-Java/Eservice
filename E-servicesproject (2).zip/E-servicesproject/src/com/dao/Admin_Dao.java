package com.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.model.Admin;
import com.model.BookService;
import com.model.Customer;
import com.model.Service;
import com.util.dbutil;

public class Admin_Dao {
	Session session;
//------------------------------admin login------------------------------------
	public boolean loginauthenticate(String ad_name, String ad_pass){
		Admin admin=loginuser(ad_name);
		if(admin!=null && admin.getAd_name().equals(ad_name)&& admin.getAd_pass().equals(ad_pass)){
			return true;
		}
		else {
			return false;
		}
	}
	public Admin loginuser(String ad_name){
		session = dbutil.getses();
		Transaction tx = null;
		Admin admin = null;
		try {
			admin=new Admin();
			tx=session.getTransaction();
			tx.begin();
			Query query=session.createQuery("from Admin where ad_name='"+ad_name+"'");
			admin=(Admin)query.uniqueResult();
			tx.commit();
		} catch (Exception e) {
			if (tx != null) {
				tx.rollback();
			}	
			e.printStackTrace();	 
		}
		return admin;
	}
	
	//-----------------------------------------add, retrive, update and delete admin new admin----------------------------
	
	public void addNewAdmin(Admin admin) {
		session=dbutil.getses();
		Transaction tr=session.beginTransaction();
		session.save(admin);
		tr.commit();
		session.close();
	}
	public Admin getadmin(int ad_id) {
		session=dbutil.getses();
		Admin admin=session.get(Admin.class, ad_id);
		return admin;
	}
	
	public void updatepass(Admin admin) {
		session=dbutil.getses();
		Transaction tr=session.beginTransaction();
		session.update(admin);
		tr.commit();
		session.close();
	}
	
	//-------------------------------------retrive all customer details-------------------------------------
	
	public List<Customer> getallCustomers(){
		session=dbutil.getses();
		List<Customer> list=session.createQuery("from Customer").list();
		return list;
	}
	
	//-----------------------------------retrive all book detail......................................
	
	public List<BookService> getallbooklist() {
		session=dbutil.getses();
		List<BookService> list=session.createQuery("from BookService").list();
		return list;
	}
	public List<BookService> getbooking(String status){
		session=dbutil.getses();
		List<BookService> list=session.createQuery("from BookService where status='"+status+"'").list();
		return list;
	}
	//---------------------------------------homepage---------------------------------------------
	
	
	
}
