package com.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.dao.Customer_Datadao;

import com.model.BookService;
import com.model.Customer;
import com.model.Message;
import com.model.Service;


@WebServlet("/customer_controller")
public class customer_controller extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         
		String action=request.getParameter("action");
		if(action.equalsIgnoreCase("logout")) {
			HttpSession session2=request.getSession();
			session2.removeAttribute("customer");
			session2.invalidate();
			response.sendRedirect("cust_login.jsp");
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Customer_Datadao dao=new Customer_Datadao();
		Customer customer = new Customer();
		Message message=new Message();
		Service service=new Service();
		BookService book=new BookService();


		String action=request.getParameter("action");
		if(action.equalsIgnoreCase("register")) {
			customer.setCu_num(Long.parseLong(request.getParameter("cust_num")));
			String cu_name=request.getParameter("cust_name");
			customer.setCu_name(cu_name);
			String cu_email=request.getParameter("cust_email");
			customer.setCu_email(cu_email);
			customer.setCu_pass(request.getParameter("cust_pass"));
			customer.setCu_add(request.getParameter("cust_address"));
			customer.setCu_city(request.getParameter("cust_city"));
			customer.setCu_gender(request.getParameter("cust_gender"));

			boolean auth=dao.isuserexist(customer);

			if(auth==true) {
				String sub="Congratulation!! sucessfully registered";
				String msg="dear, "+ cu_name+ "you have registered with E-services.com. Thanks for choosing our services...";
				dao.setemail(cu_email,sub,msg);
				dao.insert(customer);
				request.setAttribute("reg_done", "Registration Done Sucessfully, Please login....");
				request.getRequestDispatcher("cust_login.jsp").forward(request, response);
			}
			else{
				request.setAttribute("reg_fail", "User already awailable please login with correct credentials........");
				request.getRequestDispatcher("cust_login.jsp").forward(request, response);
			}


		}
		else if(action.equalsIgnoreCase("login")) {
			String email=request.getParameter("cust_email");
			String pass=request.getParameter("cust_pass");
			boolean login=dao.loginauthenticate(email, pass);
			if(login==true) {
				customer=dao.loginuser(email);
				HttpSession session=request.getSession();
				session.setAttribute("customer", customer);
				request.getRequestDispatcher("cust_homepage.jsp").forward(request, response);
			}
			else {
				request.setAttribute("login_fail", " please login with correct credentials........");
				request.getRequestDispatcher("cust_login.jsp").forward(request, response);
			}

		}
		else if(action.equalsIgnoreCase("Submit Email")) {
			String email=request.getParameter("cu_email");
			customer=dao.loginuser(email);
			if(customer!=null) {
				request.setAttribute("customer", customer);
				request.getRequestDispatcher("setPassword.jsp").forward(request, response);
			}
			else {
				request.setAttribute("notawl", "email does not match with database");
				request.getRequestDispatcher("forgotpassword.jsp").forward(request, response);
			}
		}
		else if(action.equalsIgnoreCase("Set Password")) {
			customer.setCu_id(Integer.parseInt(request.getParameter("cu_id")));
			customer.setCu_name(request.getParameter("cu_name"));
			customer.setCu_email(request.getParameter("cu_email"));
			customer.setCu_pass(request.getParameter("cu_pass"));
			customer.setCu_add(request.getParameter("cu_add"));
			customer.setCu_gender(request.getParameter("cu_gender"));
			customer.setCu_pass(request.getParameter("cu_pass"));
			customer.setCu_num(Long.parseLong(request.getParameter("cu_num")));


			dao.updatepass(customer);

			request.setAttribute("pass_updated", "password Updated Sucessfully plese login");
			request.getRequestDispatcher("cust_login.jsp").forward(request, response);
		}


		else if(action.equalsIgnoreCase("BOOK")) {
			service.setSer_id(Integer.parseInt(request.getParameter("ser_id")));
			HttpSession session=request.getSession();
			customer=(Customer)session.getAttribute("customer");
			book.setCustomer(customer);
			book.setService(service);
			book.setStatus("booked");
			book.setDate(LocalDate.now().toString());

			String sub="service book on e-services";
			String msg="Dear, "+ customer.getCu_name()+ " you have booked "+ "service on e-services... our service man will be soon at your place..."
					+ "thank you for choosing our services";
			dao.setemail(customer.getCu_email(),sub,msg);
			dao.bookservice(book);

			request.setAttribute("book", "service book done");
			request.getRequestDispatcher("cust_homepage.jsp").forward(request, response);

		}

		else if(action.equalsIgnoreCase("Edit")) {
			int cust_id=Integer.parseInt(request.getParameter("cust_id"));
			customer.setCu_id(cust_id);
			customer.setCu_name(request.getParameter("cust_name"));
			customer.setCu_email(request.getParameter("cust_email"));
			customer.setCu_pass(request.getParameter("cust_pass"));
			customer.setCu_add(request.getParameter("cust_add"));
			customer.setCu_gender(request.getParameter("cust_gender"));
			customer.setCu_city(request.getParameter("cust_city"));
			customer.setCu_num(Long.parseLong(request.getParameter("cust_num")));
			
			dao.updatecust(customer);
			
			request.setAttribute("Cust_updated", "Information updated sucessfully");
			request.getRequestDispatcher("cust_login.jsp").forward(request, response);
		}
		
		else if(action.equalsIgnoreCase("SEND")) {
			message.setEmail(request.getParameter("cont_email"));
			message.setName(request.getParameter("cont_name"));
			message.setMesage(request.getParameter("cont_msg"));
			
			dao.message(message);

			request.setAttribute("msg", "message send sucessfully");
			request.getRequestDispatcher("contact.jsp").forward(request, response);

		}
		else if(action.equalsIgnoreCase("SEND EMAIL")) {
			message.setEmail(request.getParameter("cont_email"));
			message.setName(request.getParameter("cont_name"));
			message.setMesage(request.getParameter("cont_msg"));
			
			dao.message(message);

			request.setAttribute("msg", "message send sucessfully");
			request.getRequestDispatcher("contact1.jsp").forward(request, response);

		}

		

	}

}
