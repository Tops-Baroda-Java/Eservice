package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.Agency_dao;
import com.dao.Customer_Datadao;
import com.model.Agency;
import com.model.Customer;

@WebServlet("/Agencycontroller")
public class Agencycontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Agency ag=new Agency();
		Agency_dao adao=new Agency_dao();
		Customer_Datadao cdao=new Customer_Datadao();
		
		String action=request.getParameter("action");
		if(action.equalsIgnoreCase("REGISTER")) {
			
			
			
			
			
			String agname=request.getParameter("ag_name");
			ag.setAg_name(agname);
			String email=request.getParameter("ag_email");
			ag.setAg_email(email);
			ag.setAg_address(request.getParameter("ag_address"));
			ag.setAg_city(request.getParameter("ag_city"));
			ag.setAg_kp(request.getParameter("ag_kp"));
			ag.setAg_pass(request.getParameter("ag_pass"));
			ag.setAg_num(Long.parseLong(request.getParameter("ag_num")));
			ag.setAg_ser(request.getParameter("ag_ser"));
			
			boolean b=adao.isagencyexist(ag);
			if(b==true) {
				adao.add_agency(ag);
				
				String message="Hello "+agname+" \nWelcome to e-services family. you are notify through email when customer select any of your services... ";	
				
				cdao.setemail(email, "registration on e-services", message);
				
				request.setAttribute("done", "Registartion sucessfully done, Pleae check your email");
				request.getRequestDispatcher("serviceAgency.jsp").forward(request, response);
			}
			
			else {
				request.setAttribute("fail", "Already avilable for any query please contact to e-service admin");
				request.getRequestDispatcher("serviceAgency.jsp").forward(request, response);
			}
			
		}
		
		
	}
	
	

}
