package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.Admin_Dao;
import com.dao.Customer_Datadao;
import com.dao.Service_Dao;
import com.model.Admin;
import com.model.BookService;


@WebServlet("/Admin_Controller")
public class Admin_Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		Admin_Dao adao=new Admin_Dao();
		Admin admin=new Admin();
		if(action.equalsIgnoreCase("logout")) {
			HttpSession session=request.getSession();
			session.removeAttribute("admin");
			session.invalidate();
			response.sendRedirect("adminlogin.jsp");
		}
		else if(action.equalsIgnoreCase("passchange")) {
			int id=Integer.parseInt(request.getParameter("ad_id"));
			admin=adao.getadmin(id);
			request.setAttribute("admin", admin);
			request.getRequestDispatcher("admin_passchange.jsp").forward(request, response);
		}
		else if(action.equalsIgnoreCase("Change Password")) {
			String ad_pas=request.getParameter("ad_pass");
			admin.setAd_id(Integer.parseInt(request.getParameter("ad_id")));
			admin.setAd_name(request.getParameter("ad_name"));
			admin.setAd_pass(request.getParameter("ad_pass"));
			
			adao.updatepass(admin);
			request.setAttribute("done", "password change sucessfully");
			request.getRequestDispatcher("adminHomepage.jsp").forward(request, response);
			
			
		}
		
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");

		Admin_Dao adao;
		Customer_Datadao cdao=new Customer_Datadao();

		if(action.equalsIgnoreCase("login")) {
			Admin	admin=new Admin();
			String ad_name=request.getParameter("ad_name");
			String ad_pass=request.getParameter("ad_pass");
			admin.setAd_name(ad_name);
			admin.setAd_pass(ad_pass);
			adao=new Admin_Dao();
			boolean result=adao.loginauthenticate(ad_name, ad_pass);
			if(result==true) {
				admin=adao.loginuser(ad_name);
				HttpSession session=request.getSession();
				session.setAttribute("admin", admin);
				request.getRequestDispatcher("adminHomepage.jsp").forward(request, response);
			}
			else {
				request.setAttribute("fail","wrong credential please fill correct details");
				request.getRequestDispatcher("adminlogin.jsp").forward(request, response);
			}

		}
		else if(action.equalsIgnoreCase("create")){
			Admin admin=new Admin();
			String ad_name=request.getParameter("ad_name");
			String ad_pass=request.getParameter("ad_pass");
			admin.setAd_name(ad_name);
			admin.setAd_pass(ad_pass);
			adao=new Admin_Dao();
			adao.addNewAdmin(admin);
			request.setAttribute("done",ad_name+" is successfully added as a new admin");
			request.getRequestDispatcher("adminHomepage.jsp").forward(request, response);
		}
		
		else if(action.equalsIgnoreCase("send")) {
			String email=request.getParameter("email");
			String message=request.getParameter("message");
			cdao.setemail(email, "reply from Eservices",message);
			request.setAttribute("senddone","send message sucessfully to "+email);
			request.getRequestDispatcher("admin_showmsg.jsp").forward(request, response);
			
		}
		
		
	}

}
