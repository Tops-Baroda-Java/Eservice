package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.Customer_Datadao;
import com.dao.Service_Dao;
import com.model.BookService;
import com.model.Customer;
import com.model.Service;


@WebServlet("/Service_Controller")
public class Service_Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String action=request.getParameter("action");
	Service service=new Service();
	Customer customer=new Customer();
	
	Service_Dao dao=new Service_Dao();
	BookService book=new BookService();
	Customer_Datadao cdao=new Customer_Datadao();
	
	if(action.equalsIgnoreCase("Add Service")) {
		String ser_type=request.getParameter("ser_type");
		service.setSer_type(ser_type);
		service.setSer_name(request.getParameter("ser_name"));
		service.setSer_subname(request.getParameter("ser_subname"));
		dao.addService(service);
		request.setAttribute("done_ser","services added succefully");
		request.setAttribute("ser", ser_type);
		request.getRequestDispatcher("showser_services.jsp").forward(request, response);
	}
	
	else if(action.equalsIgnoreCase("delete")) {
		String ser_type=request.getParameter("ser_type");
		int ser_id=Integer.parseInt(request.getParameter("ser_id"));
		dao.deleteService(ser_id);
		request.setAttribute("delete","services deleted succefully");
		request.setAttribute("done_ser", ser_type);
		request.getRequestDispatcher("showser_services.jsp").forward(request, response);
	}
	
	else if(action.equalsIgnoreCase("edit")) {
		
		service=dao.getService(Integer.parseInt(request.getParameter("ser_id")));
		request.setAttribute("service",service);
			request.getRequestDispatcher("service_update.jsp").forward(request, response);
			
	}
	else if(action.equalsIgnoreCase("Update Service")) {
		String ser_type=request.getParameter("ser_type");
		service.setSer_type(ser_type);
		service.setSer_id(Integer.parseInt(request.getParameter("ser_id")));
		service.setSer_name(request.getParameter("ser_name"));
		service.setSer_subname(request.getParameter("ser_subname"));
		dao.updateService(service);
		
		
		request.setAttribute("done_ser","services updated succefully");
		request.setAttribute("ser", ser_type);
		request.getRequestDispatcher("showser_services.jsp").forward(request, response);
	}
	
	else if(action.equalsIgnoreCase("change status")) {
		
		int book_id=Integer.parseInt(request.getParameter("book_id"));
		String status=request.getParameter("status");
		
		book=cdao.getBookingbyid(book_id);
		customer=book.getCustomer();
		service=book.getService();
		String ser_name=service.getSer_subname();
		String cust_email=customer.getCu_email();
		String sub="";
		if(status.equals("Confirm")) {
			sub=ser_name+" has been conformed on E-services";
		}
		else if(status.equals("Completed")) {
			sub="Sucessfully completed "+ser_name;
		}
		
		cdao.setemail(cust_email, sub,"Thank you for using E-services");
		dao.updateStatus(status,book_id);
		request.setAttribute("status_done","Status successfully updated");
		request.getRequestDispatcher("bookservicelist.jsp").forward(request, response);
		
	}
	
	}
}
