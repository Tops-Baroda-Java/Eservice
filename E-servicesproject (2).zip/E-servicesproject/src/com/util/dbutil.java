package com.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.model.Admin;
import com.model.Agency;
import com.model.BookService;
import com.model.Customer;
import com.model.Message;
import com.model.Service;

public class dbutil {

static 	Session session;
	
	public static Session getses() {
		SessionFactory sf=new Configuration().addAnnotatedClass(Customer.class)
				.addAnnotatedClass(Admin.class)
				.addAnnotatedClass(Service.class)
				.addAnnotatedClass(BookService.class)
				.addAnnotatedClass(Message.class)
				.addAnnotatedClass(Agency.class)
				.configure().buildSessionFactory();
		session=sf.openSession();
		return session;
	}
	
	
}
