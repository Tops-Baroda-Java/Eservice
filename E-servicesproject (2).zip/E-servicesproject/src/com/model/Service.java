package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Service {

	@Id
	@GeneratedValue
	private int ser_id;
	@Column
	private String ser_type;
	@Column
	private String ser_name;
	@Column
	private String ser_subname;
	public int getSer_id() {
		return ser_id;
	}
	public void setSer_id(int ser_id) {
		this.ser_id = ser_id;
	}
	public String getSer_type() {
		return ser_type;
	}
	public void setSer_type(String ser_type) {
		this.ser_type = ser_type;
	}
	public String getSer_name() {
		return ser_name;
	}
	public void setSer_name(String ser_name) {
		this.ser_name = ser_name;
	}
	public String getSer_subname() {
		return ser_subname;
	}
	public void setSer_subname(String ser_subname) {
		this.ser_subname = ser_subname;
	}
	
	
	
}
