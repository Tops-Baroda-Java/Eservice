package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Agency {
	
	@Id
	@GeneratedValue
	private int ag_id;
	@Column
	private String ag_name;
	@Column
	private String ag_kp;
	@Column
	private String ag_email;
	@Column
	private String ag_pass;
	@Column
	private String ag_address;
	@Column
	private String ag_city;
	@Column
	private long ag_num;
	@Column
	private String ag_ser;
	
	
	
	public int getAg_id() {
		return ag_id;
	}
	public void setAg_id(int ag_id) {
		this.ag_id = ag_id;
	}
	public String getAg_name() {
		return ag_name;
	}
	public void setAg_name(String ag_name) {
		this.ag_name = ag_name;
	}
	public String getAg_kp() {
		return ag_kp;
	}
	public void setAg_kp(String ag_kp) {
		this.ag_kp = ag_kp;
	}
	public String getAg_email() {
		return ag_email;
	}
	public void setAg_email(String ag_email) {
		this.ag_email = ag_email;
	}
	public String getAg_pass() {
		return ag_pass;
	}
	public void setAg_pass(String ag_pass) {
		this.ag_pass = ag_pass;
	}
	public String getAg_address() {
		return ag_address;
	}
	public void setAg_address(String ag_address) {
		this.ag_address = ag_address;
	}
	public String getAg_city() {
		return ag_city;
	}
	public void setAg_city(String ad_city) {
		this.ag_city = ad_city;
	}
	public long getAg_num() {
		return ag_num;
	}
	public void setAg_num(long ag_num) {
		this.ag_num = ag_num;
	}
	public String getAg_ser() {
		return ag_ser;
	}
	public void setAg_ser(String ag_ser) {
		this.ag_ser = ag_ser;
	}
	
	
	

}
