package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Customer {

	@Id
	@GeneratedValue
	private int cu_id;
	@Column
	private String cu_name;
	@Column
	private String cu_email;
	@Column
	private String cu_pass;
	@Column
	private String cu_add;
	@Column
	private Long cu_num;
	@Column
	private String cu_gender;
	@Column
	private String cu_city;
	
	public int getCu_id() {
		return cu_id;
	}
	public void setCu_id(int cu_id) {
		this.cu_id = cu_id;
	}
	public String getCu_name() {
		return cu_name;
	}
	public void setCu_name(String cu_name) {
		this.cu_name = cu_name;
	}
	public String getCu_email() {
		return cu_email;
	}
	public void setCu_email(String cu_email) {
		this.cu_email = cu_email;
	}
	public String getCu_pass() {
		return cu_pass;
	}
	public void setCu_pass(String cu_pass) {
		this.cu_pass = cu_pass;
	}
	public String getCu_add() {
		return cu_add;
	}
	public void setCu_add(String cu_add) {
		this.cu_add = cu_add;
	}
	public Long getCu_num() {
		return cu_num;
	}
	public void setCu_num(Long cu_num) {
		this.cu_num = cu_num;
	}
	public String getCu_gender() {
		return cu_gender;
	}
	public void setCu_gender(String cu_gender) {
		this.cu_gender = cu_gender;
	}
	
	public String getCu_city() {
		return cu_city;
	}
	public void setCu_city(String cu_city) {
		this.cu_city = cu_city;
	}
	
	
}
